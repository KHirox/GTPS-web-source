const config = {
    // **Informasi Server**
    serverIP: "gtps.example.com", // Ganti dengan IP/Domain server GTPS kamu
    serverName: "Growtopia Private Server",
    serverDesc: "Server GTPS terbaik dengan fitur menarik!",
    ownerName: "Admin GTPS",

    // **Link Sosial Media & Komunitas**
    whatsappLink: "https://chat.whatsapp.com/XXXXXXXXXXXXXX", // Ganti dengan link grup WhatsApp
    discordLink: "https://discord.gg/yourserver", // Ganti dengan link Discord server kamu

    // **Sejarah Server**
    history: {
        startDate: "1 Januari 2023",
        firstRelease: "10 Februari 2023",
        majorUpdate: "20 Juli 2023",
        description: "Server ini didirikan dengan tujuan memberikan pengalaman bermain yang adil, menyenangkan, dan penuh event menarik!"
    },

    // **Keunggulan / Fitur Server**
    features: [
        "✅ Server Stabil & No Lag",
        "🎮 Event Eksklusif Setiap Minggu",
        "🔒 Sistem Anti-Cheat Canggih",
        "🛒 Item Spesial & Limited",
        "💰 Sistem Ekonomi Fair & Seimbang",
        "👑 Ranking & Leaderboard"
    ],

    // **Testimoni Pemain**
    testimonials: [
        { name: "Junet", message: "GTPS terbaik yang pernah saya mainkan! Staff sangat ramah & update rutin!" },
        { name: "Player2", message: "Event-eventnya seru banget, banyak hadiah keren!" },
        { name: "Player3", message: "Sistem ekonominya keren! Semua item bisa didapat tanpa pay-to-win!" }
    ]
};