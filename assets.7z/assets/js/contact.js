document.addEventListener("DOMContentLoaded", function () {
    try {
        // ======= Validasi config.js Terbaca =======
        if (typeof config === "undefined" || !config.whatsappLink || !config.discordLink) {
            throw new Error("config.js tidak ditemukan, gagal dimuat, atau tidak memiliki data yang valid.");
        }
        console.log("✅ config.js berhasil dimuat untuk contact.js");

        // ======= Fungsi Update Link Kontak =======
        function updateContactLinks() {
            const whatsappLink = document.getElementById("whatsappGroup");
            const discordLink = document.getElementById("discordServer");

            if (whatsappLink) {
                whatsappLink.setAttribute("href", config.whatsappLink);
                whatsappLink.setAttribute("target", "_blank");
                whatsappLink.rel = "noopener noreferrer";
            } else {
                console.warn("⚠️ Elemen #whatsappGroup tidak ditemukan.");
            }

            if (discordLink) {
                discordLink.setAttribute("href", config.discordLink);
                discordLink.setAttribute("target", "_blank");
                discordLink.rel = "noopener noreferrer";
            } else {
                console.warn("⚠️ Elemen #discordServer tidak ditemukan.");
            }
        }

        // ======= Fungsi Load Animasi Lottie =======
        function loadLottieAnimation(id, path) {
            const checkExist = setInterval(() => {
                const container = document.getElementById(id);
                if (container) {
                    clearInterval(checkExist); // Hentikan interval jika elemen ditemukan

                    // Set ukuran tetap 70px × 70px
                    container.style.width = "70px";
                    container.style.height = "70px";

                    lottie.loadAnimation({
                        container: container,
                        renderer: "svg",
                        loop: true,
                        autoplay: true,
                        path: path
                    });
                    console.log(`🎬 Animasi Lottie dimuat untuk #${id} dengan ukuran 70px × 70px`);
                }
            }, 100); // Cek setiap 100ms
        }

        // ======= Jalankan Fungsi Utama =======
        updateContactLinks();
        loadLottieAnimation("whatsappAnim", "assets/json/icons-whatsapp.json");
        loadLottieAnimation("discordAnim", "assets/json/icons-discord.json");

    } catch (error) {
        console.error(`❌ Terjadi kesalahan di contact.js: ${error.message}`);
    }
});