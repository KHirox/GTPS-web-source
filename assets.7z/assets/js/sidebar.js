document.addEventListener("DOMContentLoaded", function () {
    const menuButton = document.getElementById("menuButton");
    const sidebar = document.getElementById("sidebar");
    const closeSidebar = document.getElementById("closeSidebar");
    const overlay = document.getElementById("overlay");

    function openSidebar() {
        document.body.classList.add("sidebar-active");
    }

    function closeSidebarMenu() {
        document.body.classList.remove("sidebar-active");
    }

    menuButton.addEventListener("click", openSidebar);
    closeSidebar.addEventListener("click", closeSidebarMenu);
    overlay.addEventListener("click", closeSidebarMenu);
});