document.addEventListener("DOMContentLoaded", function () {
    try {
        // ======= Pastikan config.js Terbaca =======
        if (typeof config === "undefined") {
            throw new Error("config.js tidak ditemukan atau gagal dimuat.");
        }
        console.log("✅ config.js berhasil dimuat.");

        // ======= Fungsi Update Elemen HTML =======
        function updateElement(id, value, fallback = "") {
            const element = document.getElementById(id);
            if (element) element.innerText = value || fallback;
        }

        // ======= Tombol Salin IP Server =======
        const copyIPButton = document.getElementById("copyIP");
        if (copyIPButton && config.serverIP) {
            copyIPButton.addEventListener("click", async () => {
                try {
                    await navigator.clipboard.writeText(config.serverIP);
                    alert(`✅ IP Server disalin: ${config.serverIP}`);
                } catch (error) {
                    alert("❌ Gagal menyalin IP");
                    console.error("❌ Error saat menyalin IP:", error);
                }
            });
        }

        // ======= Mengisi Data Server =======
        updateElement("serverName", config.serverName, "GTPS - Server Tanpa Nama");
        updateElement("serverDesc", config.serverDesc, "Deskripsi tidak tersedia");
        updateElement("ownerName", `Pemilik: ${config.ownerName || "Tidak diketahui"}`);
        updateElement("serverNameFooter", config.serverName, "GTPS");

        // ======= Mengisi Sejarah Server =======
        if (config.history) {
            updateElement("serverHistory", config.history.description, "Data sejarah belum tersedia.");
            updateElement("serverStart", config.history.startDate, "-");
            updateElement("firstRelease", config.history.firstRelease, "-");
            updateElement("majorUpdate", config.history.majorUpdate, "-");
        }

        // ======= Mengisi Keunggulan Server =======
        const featureList = document.getElementById("featureList");
        if (featureList && Array.isArray(config.features)) {
            featureList.innerHTML = "";
            config.features.forEach(feature => {
                const li = document.createElement("li");
                li.innerText = feature;
                featureList.appendChild(li);
            });
        }

        // ======= Mengisi Testimoni Pemain =======
        const testimonialList = document.getElementById("testimonialList");
        if (testimonialList && Array.isArray(config.testimonials)) {
            testimonialList.innerHTML = "";
            config.testimonials.forEach(testimonial => {
                const li = document.createElement("li");
                li.innerHTML = `<strong>${testimonial.name}:</strong> ${testimonial.message}`;
                testimonialList.appendChild(li);
            });
        }

        // ======= Mengatur Sidebar Off-Canvas =======
        const menuButton = document.getElementById("menuButton");
        const closeSidebar = document.getElementById("closeSidebar");
        const sidebar = document.getElementById("sidebar");
        const overlay = document.getElementById("overlay");

        function openSidebar() {
            sidebar.classList.add("open");
            overlay.classList.add("active");
        }

        function closeSidebarMenu() {
            sidebar.classList.remove("open");
            overlay.classList.remove("active");
        }

        if (menuButton && closeSidebar && sidebar && overlay) {
            menuButton.addEventListener("click", openSidebar);
            closeSidebar.addEventListener("click", closeSidebarMenu);
            overlay.addEventListener("click", closeSidebarMenu);
            console.log("✅ Sidebar dengan off-canvas & blur berhasil diinisialisasi.");
        } else {
            console.warn("⚠️ Elemen sidebar tidak ditemukan. Pastikan HTML memiliki elemen sidebar yang benar.");
        }

        // ======= Mengatur Link Kontak (WhatsApp & Discord) =======
        const whatsappGroup = document.getElementById("whatsappGroup");
        if (whatsappGroup && config.whatsappLink) {
            whatsappGroup.href = config.whatsappLink;
        }

        const discordServer = document.getElementById("discordServer");
        if (discordServer && config.discordLink) {
            discordServer.href = config.discordLink;
        }

    } catch (error) {
        console.error(`❌ Terjadi kesalahan: ${error.message}`, error);
        alert(`Terjadi kesalahan: ${error.message}`);
    }
});