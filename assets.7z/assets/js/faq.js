document.addEventListener("DOMContentLoaded", function () {
    const faqButtons = document.querySelectorAll(".faq-question");
    const storageKey = "faq_opened"; // Key untuk menyimpan status FAQ di localStorage

    // Fungsi untuk menutup semua FAQ
    function closeAllFAQ() {
        document.querySelectorAll(".faq-answer").forEach(answer => {
            answer.style.maxHeight = null;
            answer.style.opacity = "0";
            answer.parentElement.querySelector(".faq-question").classList.remove("active");
        });
    }

    // Fungsi untuk membuka atau menutup FAQ tertentu
    function toggleFAQ(button) {
        const answer = button.nextElementSibling;
        const isActive = button.classList.contains("active");

        closeAllFAQ(); // Tutup semua FAQ sebelum membuka yang baru

        if (!isActive) {
            button.classList.add("active");
            answer.style.maxHeight = answer.scrollHeight + "px"; // Efek slide
            answer.style.opacity = "1";
        }

        saveFAQState(); // Simpan status setelah perubahan
    }

    // Fungsi untuk menyimpan status FAQ yang terbuka
    function saveFAQState() {
        const openedFaqs = [...faqButtons]
            .filter(button => button.classList.contains("active"))
            .map(button => button.dataset.index);
        
        localStorage.setItem(storageKey, JSON.stringify(openedFaqs));
    }

    // Fungsi untuk mengembalikan status FAQ yang terbuka dari localStorage
    function restoreFAQState() {
        const openedFaqs = JSON.parse(localStorage.getItem(storageKey)) || [];

        openedFaqs.forEach(index => {
            const button = document.querySelector(`.faq-question[data-index="${index}"]`);
            if (button) {
                const answer = button.nextElementSibling;
                button.classList.add("active");
                answer.style.maxHeight = answer.scrollHeight + "px";
                answer.style.opacity = "1";
            }
        });
    }

    // Tambahkan event listener untuk setiap FAQ
    faqButtons.forEach((button, index) => {
        button.dataset.index = index; // Tambahkan indeks unik ke setiap FAQ
        button.addEventListener("click", () => toggleFAQ(button));
    });

    restoreFAQState(); // Kembalikan status FAQ saat halaman dimuat ulang
});